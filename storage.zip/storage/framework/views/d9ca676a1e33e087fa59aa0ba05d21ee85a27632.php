<?php $__env->startSection('content'); ?>
        <div class="card-body">

            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <input type="file" name="file" class="form-control">

                <br>

                <button class="btn btn-success">تحميل قائمة المعوزين</button>



            </form>

            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\9ofa\resources\views/import.blade.php ENDPATH**/ ?>