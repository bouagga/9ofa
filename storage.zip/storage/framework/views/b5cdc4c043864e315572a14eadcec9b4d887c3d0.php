<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 >قائمة المعوزين</h1>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>الاسم و اللقب</th>
                    <th>الحي</th>
                    <th>رقم الهاتف</th>
                    <th>مرات الاستفادة</th>
                    <th>تاريخ اخر الاستفادة</th>
                    <?php if(auth()->user()->is_admin == 1): ?>
                    <th>تعديل</th>
                    <th>حذف</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>

                <input type="hidden" value="<?php echo e($co=0); ?>">
                <input type="hidden" value="<?php echo e($co1=0); ?>">
                <?php $__currentLoopData = $persones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->name); ?></td>
                        <td><?php echo e($p->city); ?></td>
                        <td><?php echo e($p->phone); ?></td>
                        <td>
                            <table>
                                <tr>
                                    <td><?php echo e(count($p->baskets()->get())); ?></td>
                                    <td>
                                        <form role="form" method="post" action="<?php echo e(route('baskets.store')); ?>">

                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="person_id" value="<?php echo e($p->id); ?>">
                                            <button class="fas fa-plus" style="margin-left: 40%;color: green; "></button>
                                        </form></td>
                                    <?php if(auth()->user()->is_admin == 1): ?>
                                        <td>  <?php $__currentLoopData = $p->baskets()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <form role="form" method="post" action="<?php echo e(route('baskets.destroy',$la->id)); ?>">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="fas fa-minus" style="margin-left: 40%; color: red"></button>
                                            </form>
                                                <input type="hidden" value="<?php echo e($co1++); ?>">
                                                <?php if($co1!=0) break; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            </table>
                        </td>
                        <?php if(count($p->baskets()->get()) == 0 ): ?>
                            <td>
                                لم يستفيد بعد
                            </td>
                        <?php else: ?>
                        <?php $__currentLoopData = $p->baskets()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($la->created_at); ?>

                            <input type="hidden" value="<?php echo e($co++); ?>">

                                <?php if($co!=0) break; ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(auth()->user()->is_admin == 1): ?>
                        <td>
                            <a href="<?php echo e(route('persons.edit',$p->id)); ?>">
                                <i class="fas fa-user-edit" style="margin-left: 40%;"></i>

                            </a>
                        </td>
                        <td>    <form role="form" method="post" action="<?php echo e(route('persons.destroy',$p->id)); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="fas fa-user-times" style="margin-left: 40%;"></button>
                            </form></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
        <!-- /.card-body -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\9ofa\resources\views/persons/index.blade.php ENDPATH**/ ?>